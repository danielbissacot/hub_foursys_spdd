---
trigger: glob
globs: *.md
---

Sempre que criar um arquivo .md, utilize o padrão visual de 'Documentação Moderna de Desenvolvedor' seguindo estas diretrizes:
1 - Uso de Emojis: Comece seções principais com emojis temáticos (ex: 🚀 para 'Quick Start', 📦 para 'Instalação', 🛠️ para 'Configuração', ✅ para 'Checklist').
2 - Estrutura de Títulos: Use # para o título principal e ## para subtítulos, mantendo um espaçamento claro entre eles.
3 - Blocos de Código: Comandos de terminal devem estar em blocos de código com fundo escuro (utilize ` ` `bash ou ` ` `powershell).
4 - Tabelas de Comandos: Para guias de 'O que você quer' vs 'O que dizer/fazer', utilize o formato de tabela Markdown:

| Objetivo | Comando/Ação |
| :--- | :--- |
| Descrição | `comando` ou "Frase de Gatilho" |
5 - Destaques: Use negrito para termos chave e blocos de citação (>) para notas importantes ou conceitos de 'Conversa Natural'.

