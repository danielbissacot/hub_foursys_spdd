# Coding Principles

Behavioral bias, not checklist. Read before every implementation.

---

## Before Coding

- State assumptions explicitly. If uncertain, ask.
- Multiple interpretations exist? Present all—don't pick silently.
- Simpler approach exists? Say so. Push back when warranted.
- Something unclear? Stop. Name what's confusing. Ask.
- User's approach seems wrong? Disagree honestly. Don't be sycophantic.

---

## During Implementation

### Core Principles (SOLID, DRY, KISS, YAGNI)

- **S.O.L.I.D**: Every class/module must have a single reason to change. Prefer composition over inheritance. Protect existing code from modification by allowing extension.
- **KISS (Keep It Simple, Stupid)**: Avoid clever code. If a junior can't understand it in 10 seconds, it's too complex.
- **DRY (Don't Repeat Yourself)**: Eliminate logic duplication, but don't over-abstract shared code that is only "coincidentally" similar.
- **YAGNI (You Ain't Gonna Need It)**: Implement only what is required **now**. No "future-proofing" with hooks or parameters for hypothetical features.

### Clean Code (Robert C. Martin)

- **Meaningful Names**: Variables, functions, and classes must reveal intent. No `data`, `info`, or `process()`.
- **Small Functions**: Functions should do one thing and do it well. Keep them short and focused.
- **Boy Scout Rule**: Always leave the code slightly cleaner than you found it (within the scope of your changes).
- **Clarity over Brevity**: Write code for humans first, compilers second. Avoid mental mapping and obscure abbreviations.

### Simplicity & Practicality

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" not requested.
- No error handling for impossible scenarios.
- 200 lines that could be 50? Rewrite it.

### Surgical Changes

- Don't "improve" adjacent code, comments, or formatting unless it violates the Boy Scout Rule within your target file.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do differently.
- Unrelated dead code noticed? Mention it—don't delete it.
- Remove ONLY imports/variables/functions YOUR changes orphaned.

### Test Integrity

- NEVER weaken an existing test assertion to make it pass.
- NEVER delete a test to reduce failure count.
- NEVER use the test framework's skip/disable/pending mechanism to bypass a failing test.
- NEVER modify tests written in the RED phase during GREEN phase.
- If a test is genuinely wrong, STOP and confirm with the user before changing it.
- Tests are the spec — implementation conforms to tests, not the other way around.

---

## After Each Change

Ask: "Would Uncle Bob or a senior engineer call this overcomplicated or messy?"
If yes → simplify and clean up before proceeding.
