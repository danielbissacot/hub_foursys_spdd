# 📜 Convenções de Desenvolvimento

Este documento define as regras e o fluxo de trabalho obrigatório para o desenvolvimento do projeto.

## 🚀 Fluxo de Novas Funcionalidades (Features)

Para cada nova funcionalidade, o Agente deve seguir rigorosamente a ordem de criação de documentos abaixo, aguardando a **aprovação explícita do usuário** após cada entrega:

1.  **`spec.md`**: Especificação funcional e técnica dos requisitos.
    *   *Gate:* Aguardar aprovação do usuário.
2.  **`design.md`**: Desenho técnico incluindo diagramas Mermaid (Sequência e Classes) conforme a PRD de Arquitetura Hexagonal.
    *   *Gate:* Aguardar aprovação do usuário.
3.  **`tasks.md`**: Decomposição da funcionalidade em tarefas atômicas, granulares e orientadas a testes (TDD).
    *   *Gate:* Aguardar aprovação do usuário.

**Nenhuma implementação de código deve ser iniciada sem que os três documentos acima tenham sido validados e aprovados.**

## 🏗️ Padrões de Documentação

- Todos os arquivos `.md` devem seguir o padrão visual de **'Documentação Moderna de Desenvolvedor'** (Emojis, Títulos Claros, Tabelas e Destaques).
- Os nomes de arquivos de documentação técnica devem ser preferencialmente em **letras minúsculas**.

## 🛠️ Arquitetura e Código

- **Arquitetura Hexagonal:** Seguir estritamente a hierarquia de pacotes e sufixos definida em `docs/arquitetura-hexagonal/arquitetura-hexagonal.md`.
- **Verificação Cruzada de PRDs Técnicas:** Antes de elaborar `spec.md` ou `design.md`, o Agente **DEVE** ler a PRD de implementação correspondente (ex: `GET-plan-implementation.md`) na pasta `docs/arquitetura-hexagonal/`. Em caso de divergência entre a *User Story* e a PRD técnica, o padrão técnico da Vila Moradia prevalece para a estrutura e semântica RESTful.
- **Independência de Framework:** O `core` (application/domain) deve ser agnóstico a frameworks sempre que possível.
- **Mapeamento:** Uso obrigatório de `MapStruct` para conversão entre camadas.
- **Segurança:** Uso obrigatório da anotação `@Secured` em todos os Controllers.
