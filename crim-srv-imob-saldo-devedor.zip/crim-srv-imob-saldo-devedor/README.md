# 🚀 SRV Java Maven Template

<div align="center">
  
![Java](https://img.shields.io/badge/Java-21-ED8B00?style=for-the-badge&logo=java)
![Spring Boot](https://img.shields.io/badge/Spring_Boot-3.5.x-6DB33F?style=for-the-badge&logo=spring)
![Spring Cloud](https://img.shields.io/badge/Spring_Cloud-2025.0.0-6DB33F?style=for-the-badge&logo=spring)
![JUnit](https://img.shields.io/badge/JUnit-5-25A162?style=for-the-badge&logo=junit5)
![Maven](https://img.shields.io/badge/Maven-3-C71A36?style=for-the-badge&logo=apache-maven)
![Pitest](https://img.shields.io/badge/Pitest-1.20.2-2E9FD5?style=for-the-badge)

</div>

<div align="center">
  <p><strong>Template de serviço Java e Spring Boot para desenvolvimento na Cloud Pública</strong></p>
  <p>
    <a href="#visão-geral">Visão Geral</a> •
    <a href="#pré-requisitos">Pré-requisitos</a> •
    <a href="#quickstart">Quickstart</a> •
    <a href="#testes">Testes</a> •
    <a href="#documentação">Documentação</a> •
    <a href="#monitoramento">Monitoramento</a> •
    <a href="#contribuição">Contribuição</a> •
    <a href="#links-úteis">Links Úteis</a>
  </p>
</div>

> [!IMPORTANT]
> Este é um template oficial do Kit de desenvolvimento para Java e Spring Boot. Após a criação dos artefatos baseados neste template, a manutenção e evolução é de responsabilidade da equipe. Mantenha-se atualizado com as evoluções do Spring e bibliotecas Bradesco!

## 📋 Visão Geral

Este template foi projetado para acelerar o desenvolvimento de aplicações Java usando Spring Boot na Cloud Pública, seguindo as melhores práticas de arquitetura e padrões da organização.

### Principais características

- ✅ **Arquitetura Hexagonal**: Implementação com divisão clara de responsabilidades
- ✅ **API RESTful**: Construção de endpoints seguindo padrões REST
- ✅ **Documentação Automática**: Swagger UI integrado
- ✅ **Observabilidade**: Métricas, logs e health checks integrados
- ✅ **DevOps Ready**: Configurado com pipelines CI/CD e notificações
- ✅ **Testes Automatizados**: Unitários, integração e funcionais

## 🛠️ Pré-requisitos

| Requisito | Versão | Descrição |
|-----------|--------|-----------|
| JDK | 21+     | OpenJDK LTS |
| Maven | 3.8+   | Gerenciador de dependências |
| Git | -      | Controle de versão |
| IDE | -      | IntelliJ, Eclipse ou VS Code |
| Container Runtime | -      | Docker, Podman (opcional) |
| Acesso | -      | NEXUS Bradesco |

## 🏃‍♂️ Quickstart

### Clone e build

```bash
# Clone o repositório
git clone <url-do-seu-repositorio>

# Acesse o diretório
cd srv-java-maven-template

# Build do projeto
./mvnw clean install
```

### Execução local

<details>
<summary>Profile LOCAL (desenvolvimento)</summary>

```bash
export SPRING_PROFILES_ACTIVE=LOCAL
java -jar target/java-maven-template.jar
```

Acesse: http://localhost:8087/api/api-docs
</details>

<details>
<summary>Profile DEV (integração)</summary>

```bash
export SPRING_PROFILES_ACTIVE=DEV
java -jar target/java-maven-template.jar
```
</details>

<details>
<summary>Execução em container</summary>

```bash
# Build da imagem
docker build -t myapp-java-test -f docker/Dockerfile .

# Execução
docker run -dp 8088:8080 myapp-java-test
```
</details>

<details>
<summary>Modo debug</summary>

```bash
java -Xdebug -Xrunjdwp:transport=dt_socket,server=y,address=5005,suspend=y -jar target/java-maven-template.jar
```

Na sua IDE:
1. Run > Edit configurations... > '+' > Remote JVM Debug
2. Configure: Name=AppRemote, Host=localhost, Port=5005
3. Run > Debug 'AppRemote'
</details>

## 🧪 Testes

### Testes Unitários

```bash
# Executar todos os testes unitários
mvn test

# Executar com relatório de cobertura
mvn test jacoco:report
```

### Testes de Integração

Testes de integração garantem que diferentes partes do sistema funcionam corretamente juntas, simulando cenários reais de uso e comunicação entre módulos, serviços ou componentes.
No caso de artefato Spring Boot, saiba que exite recurso que permitem testes de integração com recursos embarcados. Veja em [Testing Spring Boot Applications](https://docs.spring.io/spring-boot/reference/testing/spring-boot-applications.html).

- **Padrão de nomeação dos arquivos:**  
  - `**/IT*.java`  
  - `**/*IT.java`  
  - `**/*ITCase.java`
  - `**/*IntegrationTest.java`
- **Localização:**  
  Os testes de integração devem ser colocados em `src/test/java/integracao`, conforme configurado no Maven Failsafe plugin. Utilize subpastas específicas de integração apenas se configuradas explicitamente no `pom.xml`.
- **Execução dos testes de integração:**  
  Para rodar apenas os testes de integração, utilize:
  ```bash
  mvn verify
  ```
- **Relatórios:**  
  Para gerar relatórios usando o Maven Failsafe:
  ```bash
  mvn failsafe:integration-test failsafe:verify
  ```
  Os relatórios são gerados em `target/surefire-reports` e podem ser integrados ao SonarQube ou Allure.

> [!TIP]
> Testes de integração são essenciais para garantir que o sistema funcione corretamente em cenários reais, evitando problemas de comunicação entre módulos e regressões.

### Testes Funcionais Automatizados

```bash
# Executar testes específicos
mvn test "-Dcucumber.features=src/test/resources/features/usuarios" "-Dtest=RegressionTest" "-DclassPath=functional.RegressionTest" "-Dsurefire.includeJUnit5Engines=cucumber"

# Gerar relatório Allure
mvn bradesco:report
```


## 📚 Documentação

### Swagger UI

- **Local**: http://localhost:8080/swagger-ui/index.html
- **Ambientes**: http://IP_SERVIDOR:8080/swagger-ui/index.html

> [!NOTE]
> Por questões de segurança, o Swagger está desabilitado em ambiente produtivo (PRD).

## 📈 Monitoramento

### Spring Actuator

O Spring Actuator está configurado para fornecer informações sobre o status da aplicação:

- **Health**: http://localhost:8080/health
- Integrado com probes Kubernetes (liveness e readiness)

## 🤝 Contribuição

1. Certifique-se de que os testes estão passando antes de submeter um PR
2. Siga os padrões de código e documentação
3. Mantenha a compatibilidade com os ambientes de execução

## 🔗 Links Úteis

<details>
<summary>Documentação e Referências</summary>

* [Welcome KIT LEAP](https://confluence.bradesco.com.br:8443/display/HBLESC/Pagina+Principal)
* [Arquitetura de referência](https://confluence.bradesco.com.br:8443/pages/viewpage.action?pageId=136730699)
* [Treinamento Cloud Pública](https://confluence.bradesco.com.br:8443/pages/viewpage.action?pageId=244976149)
* [API Studio | Open APIs](https://confluence.bradesco.com.br:8443/display/OPAPIS/Plataforma+OpenAPIs)
* [Automação de Testes](https://confluence.bradesco.com.br:8443/pages/viewpage.action?pageId=1630012284)
</details>

<details>
<summary>Ferramentas e Sistemas</summary>

* [Bitbucket](https://bitbucket.bradesco.com.br:8443/)
* [Nexus](https://nexusrepository.bradesco.com.br:8443/)
* [Github](https://github.com/Bradesco-Core/)
* [ArgoCD DEV](https://argocd.corpti.bradesco.com.br/)
* [Jira](https://jira.bradesco.com.br:8443/)
* [Plataforma Tech Academy](https://intranet.net.bradesco.com.br/gtti/)
</details>

---

<div align="center">
  <p>Desenvolvido com ❤️ pela equipe Bradesco</p>
</div>
