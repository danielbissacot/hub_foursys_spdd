# PRD: Implementação de Chamadas DELETE — Padrão Vila Moradia

## 1. Visão Geral
Define as regras obrigatórias para a implementação de operações de exclusão de recursos em microsserviços da Vila Moradia. O padrão foca em segurança e conformidade com o retorno de remoção.

## 2. Padrões de Endpoint e Resposta

### 2.1 Exclusão de Recurso
Utilizado para remover logicamente ou fisicamente uma entidade do sistema.

*   **Verbo HTTP**: `DELETE`
*   **Path**: `/{recurso}/{id}` (Ex: `/contratos/{numeroContrato}`)
*   **Status de Sucesso**: `204 No Content` (padrão preferencial quando não há corpo de retorno).
*   **Status de Erro (Não Encontrado)**: `404 Not Found` (se o ID não existir e a regra exigir erro) ou manter `204` para garantir idempotência técnica.

## 3. Diretrizes Técnicas
*   **Idempotência**: O DELETE deve ser idempotente. Chamar a exclusão de um item que já foi excluído deve retornar sucesso (204) ou um erro controlado, não afetando o estado final.
*   **Segurança**: Operações de exclusão devem ter validações rigorosas de permissão na camada de negócio.

## 4. Fluxo de Implementação (Hexagonal)

O fluxo deve obrigatoriamente seguir as camadas:
1.  **Controller**: Recebe o identificador via `@PathVariable`, valida o formato e chama o `UseCase`.
2.  **UseCase**: Interface de entrada no hexágono.
3.  **Application Service**: Implementação do UseCase que orquestra a remoção.
4.  **Domain Service**: Valida se o recurso pode ser excluído.
5.  **Port Out**: Interface de saída para exclusão.
6.  **Adapter Out (Persistence)**: Implementa a Port Out e executa o comando de delete no banco de dados.

### 4.1 Diagrama de Classes
```mermaid
classDiagram
    class DominioController {
        +excluirRecurso(id) void
    }
    class DominioSwagger {
        <<interface>>
        +excluirRecurso(...)
    }
    class DominioUseCase {
        <<interface>>
        +excluirRecurso(id) void
    }
    class DominioApplicationService {
        -DominioService service
        +excluirRecurso(id) void
    }
    class DominioService {
        -DominioPort port
        +excluirRecurso(id) void
    }
    class DominioPort {
        <<interface>>
        +excluir(id) void
    }
    class DominioPersistence {
        -DominioRepository repository
        +excluir(id) void
    }
    class DominioRepository {
        -LibRepository libRepository
        +excluirContrato(id) void
    }
    class LibRepository {
        <<Library>>
        +delete(MapBuilder)
    }

    DominioController ..|> DominioSwagger
    DominioController --> DominioUseCase
    DominioApplicationService ..|> DominioUseCase
    DominioApplicationService --> DominioService
    DominioService --> DominioPort
    DominioPersistence ..|> DominioPort
    DominioPersistence --> DominioRepository
    DominioRepository --> LibRepository
```

### 4.2 Diagrama de Sequência
```mermaid
sequenceDiagram
    participant C as Cliente
    participant Ctrl as DominioController
    participant UC as DominioUseCase
    participant Ser as DominioApplicationService
    participant Prt as DominioPort
    participant Per as DominioPersistence
    participant Rep as DominioRepository
    participant Lib as LibRepository (imob-lib)
    participant DB as Banco de Dados

    C->>Ctrl: DELETE /api/v1/[recurso]/{id}
    activate Ctrl
    Ctrl->>UC: excluirRecurso(id)
    activate UC
    UC->>Ser: excluirRecurso(id)
    activate Ser
    Ser->>Dom: excluirRecurso(id)
    activate Dom
    Dom->>Prt: excluir(id)
    activate Prt
    Prt->>Per: excluir(id)
    activate Per
    Per->>Rep: excluirContrato(id)
    activate Rep
    Rep->>Lib: delete(MapBuilder)
    activate Lib
    Lib->>DB: delete/call procedure
    activate DB
    DB-->>Lib: void/success
    deactivate DB
    Lib-->>Rep: sucesso
    deactivate Lib
    Rep-->>Per: sucesso
    deactivate Rep
    Per-->>Prt: sucesso
    deactivate Per
    Prt-->>Dom: sucesso
    deactivate Prt
    Dom-->>Ser: sucesso
    deactivate Dom
    Ser-->>UC: sucesso
    deactivate Ser
    UC-->>Ctrl: sucesso
    deactivate UC
    Ctrl-->>C: 204 No Content
    deactivate Ctrl
```

> [!IMPORTANT]
> **Diretrizes para Implementação de Banco de Dados (LibRepository e Entities)**:
> 1. A classe `LibRepository` não é genérica. Você **DEVE** injetar a implementação real fornecida pelas bibliotecas da fundação. Exemplo: `br.com.bradesco.imob.lib.db2.dao.RepositoryDB2`.
> 2. O mapeamento do banco de dados (Entity) **NÃO** deve ser um `record` simples. Ele deve ser uma classe anotada com `@Data`, deve obrigatoriamente estender `br.com.bradesco.imob.lib.db2.entity.BasicEntity` e seus atributos devem utilizar a anotação `@Column(fieldName = "NOME_COLUNA")`.
> 3. A chamada para a procedure deve utilizar o builder de comando SQL: `MapBuilder.build(TipoComandoSql.PROCEDURE).schemaName(SCHEMA).procedure(NOME_PROC).set("PARAM", valor)`.
> 4. As exceções de banco do tipo `Db2ResultConversionException` devem ser capturadas pelo Repository e relançadas como exceções de infraestrutura (ex: `PersistenceException` ou customizada da sua aplicação) para não vazar a biblioteca externa ao *Core* (Domain).



## 5. Exemplo de Referência (Baseado em Contrato)

### Controller
```java
@DeleteMapping("/contratos/{numeroContrato}")
public ResponseEntity<Void> excluirContrato(
        @PathVariable 
        @NotNull @DecimalMin("1") BigDecimal numeroContrato) {
    contratoUseCase.excluirContrato(numeroContrato);
    return ResponseEntity.noContent().build();
}
```

## 6. Diretrizes de Governança
*   Prefira a exclusão lógica (*Soft Delete*) em recursos críticos para fins de auditoria, tratando essa lógica no `Adapter Out` ou `Domain Service`.
*   Assegure que os logs de sistema registrem quem realizou a exclusão e em qual data.
