# PRD: Implementação de Chamadas GET — Padrão Vila Moradia

## 1. Visão Geral
Define as regras obrigatórias para a implementação de operações de consulta (recuperação de dados) em microsserviços da Vila Moradia. O objetivo é garantir consistência na exposição de recursos e conformidade com os princípios RESTful e Hexagonais.

## 2. Padrões de Endpoint e Resposta

### 2.1 Consulta de Recurso Único
Utilizado para buscar um objeto específico por meio de um identificador único na URL.

*   **Verbo HTTP**: `GET`
*   **Path**: `/{recurso}/{id}` (Ex: `/contratos/{numeroContrato}`)
*   **Status de Sucesso**: `200 OK`
*   **Status de Erro (Não Encontrado)**: `404 Not Found` (Lançado pela camada de aplicação/serviço).
*   **Corpo da Resposta**: Objeto do tipo `Response` (DTO).

### 2.2 Consulta de Lista de Recursos
Utilizado para buscar múltiplos objetos, geralmente aplicando filtros via parâmetros de busca.

*   **Verbo HTTP**: `GET`
*   **Path**: `/{recurso}` (Ex: `/contratos`)
*   **Parâmetros**: Devem ser passados via `@RequestParam` (Query Parameters).
*   **Status de Sucesso**: `200 OK`
*   **Corpo da Resposta**: `List<Response>` (DTO). No caso de lista vazia, retornar `[]` com status `200 OK`.

## 3. Fluxo de Implementação (Hexagonal)

O fluxo deve obrigatoriamente seguir as camadas:
1.  **Controller**: Recebe parâmetros, valida via JSR-303 (`@NotNull`, `@Min`, etc.) e invoca o `UseCase`.
2.  **UseCase**: Interface que define a entrada no hexágono.
3.  **Application Service**: Implementação do `UseCase` que orquestra o fluxo inicial.
4.  **Domain Service**: Aplica regras de negócio e orquestra a chamada para a porta de saída.
5.  **Port Out**: Interface de saída para busca de dados.
6.  **Adapter Out (Persistence)**: Implementa a `Port Out`, executa a busca e mapeia para o `Model`.

### 3.1 Diagrama de Classes
```mermaid
classDiagram
    class DominioController {
        +obterRecurso(id) DominioResponse
        +listarRecursos(filtros) List~DominioResponse~
    }
    class DominioSwagger {
        <<interface>>
        +obterRecurso(...)
        +listarRecursos(...)
    }
    class DominioUseCase {
        <<interface>>
        +obterRecurso(id) Dominio
    }
    class DominioApplicationService {
        -DominioService service
        +obterRecurso(id) Dominio
    }
    class DominioService {
        -DominioPort port
        +obterRecurso(id) Dominio
    }
    class DominioPort {
        <<interface>>
        +buscarPorId(id) Dominio
    }
    class DominioPersistence {
        -DominioRepository repository
        +buscarPorId(id) Dominio
    }
    class DominioRepository {
        -LibRepository libRepository
        +obterPorId(id) DominioEntity
    }
    class LibRepository {
        <<Library>>
        +findOne(MapBuilder, Class)
    }

    DominioController ..|> DominioSwagger
    DominioController --> DominioUseCase
    DominioApplicationService ..|> DominioUseCase
    DominioApplicationService --> DominioService
    DominioService --> DominioPort
    DominioPersistence ..|> DominioPort
    DominioPersistence --> DominioRepository
    DominioRepository --> LibRepository
```

### 3.2 Diagrama de Sequência
```mermaid
sequenceDiagram
    participant C as Cliente
    participant Ctrl as DominioController
    participant UC as DominioUseCase
    participant Ser as DominioApplicationService
    participant Prt as DominioPort
    participant Per as DominioPersistence
    participant Rep as DominioRepository
    participant Lib as LibRepository (imob-lib)
    participant DB as Banco de Dados

    C->>Ctrl: GET /api/v1/[recurso]/{id}
    activate Ctrl
    Ctrl->>UC: obterRecurso(id)
    activate UC
    Ser->>UC: obterRecurso(id)
    activate Ser
    Ser->>Dom: obterRecurso(id)
    activate Dom
    Dom->>Prt: buscarPorId(id)
    activate Prt
    Prt->>Per: buscarPorId(id)
    activate Per
    Per->>Rep: obterPorId(id)
    activate Rep
    Rep->>Lib: findOne(MapBuilder, Entity.class)
    activate Lib
    Lib->>DB: query/call procedure
    activate DB
    DB-->>Lib: ResultSet/Data
    deactivate DB
    Lib-->>Rep: DominioEntity
    deactivate Lib
    Rep-->>Per: DominioEntity
    deactivate Rep
    Per->>Per: Map Entity para Model
    Per-->>Prt: Dominio Model
    deactivate Per
    Prt-->>Dom: Dominio Model
    deactivate Prt
    Dom-->>Ser: Dominio Model
    deactivate Dom
    Ser-->>UC: Dominio Model
    deactivate Ser
    UC-->>Ctrl: Dominio Model
    deactivate UC
    Ctrl->>Ctrl: Map Model para Response
    Ctrl-->>C: 200 OK (DominioResponse)
    deactivate Ctrl
```

> [!IMPORTANT]
> **Diretrizes para Implementação de Banco de Dados (LibRepository e Entities)**:
> 1. A classe `LibRepository` não é genérica. Você **DEVE** injetar a implementação real fornecida pelas bibliotecas da fundação. Exemplo: `br.com.bradesco.imob.lib.db2.dao.RepositoryDB2`.
> 2. O mapeamento do banco de dados (Entity) **NÃO** deve ser um `record` simples. Ele deve ser uma classe anotada com `@Data`, deve obrigatoriamente estender `br.com.bradesco.imob.lib.db2.entity.BasicEntity` e seus atributos devem utilizar a anotação `@Column(fieldName = "NOME_COLUNA")`.
> 3. A chamada para a procedure deve utilizar o builder de comando SQL: `MapBuilder.build(TipoComandoSql.PROCEDURE).schemaName(SCHEMA).procedure(NOME_PROC).set("PARAM", valor)`.
> 4. As exceções de banco do tipo `Db2ResultConversionException` devem ser capturadas pelo Repository e relançadas como exceções de infraestrutura (ex: `PersistenceException` ou customizada da sua aplicação) para não vazar a biblioteca externa ao *Core* (Domain).


## 4. Exemplo de Referência (Baseado em Contrato)

### Controller
```java
@GetMapping("/contratos/{numeroContrato}")
public ResponseEntity<ContratoResponse> obterContrato(
        @PathVariable 
        @NotNull @DecimalMin("1") BigDecimal numeroContrato) {
    var contrato = contratoUseCase.obterContrato(numeroContrato);
    var response = ContratoMapper.INSTANCE.toResponse(contrato);
    return ResponseEntity.ok(response);
}

@GetMapping("/contratos")
public ResponseEntity<List<ContratoResponse>> obterListaContratos(
        @RequestParam("numero_cpf") @NotNull Long numeroCpf) {
    var response = ContratoMapper.INSTANCE.toResponseList(
            contratoUseCase.obterListaContratos(numeroCpf));
    return ResponseEntity.ok(response);
}
```

## 5. Diretrizes de Governança
*   Sempre use Mappers para evitar o vazamento do modelo de domínio ou entidades de banco.
*   Documente o comportamento esperado via anotações Swagger/OpenAPI na interface de Swagger.
*   Padrão de nomenclatura de paths deve ser em plural e snake_case para parâmetros (ex: `numero_cpf`).

