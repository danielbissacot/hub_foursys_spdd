# 🛠️ Diretrizes de Implementação: Oracle (Stored Procedures)

Este documento descreve o padrão obrigatório para acesso a dados no banco de dados **Oracle** utilizando a biblioteca corporativa `imob-lib-oracle`.

## 📦 1. Dependência Necessária

Certifique-se de que a biblioteca está presente no seu `pom.xml`:

```xml
<dependency>
    <groupId>br.com.bradesco.imob</groupId>
    <artifactId>imob-lib-oracle</artifactId>
    <version>${imob-lib-oracle.version}</version>
</dependency>
```

## 📋 2. Regras de Ouro (Oracle)

1.  **Injeção do Repository**: Utilize a classe `br.com.bradesco.imob.lib.oracle.repository.Repository`.
2.  **Mapeamento de Entidade**: As classes `Entity` **DEVEM** implementar `br.com.bradesco.imob.lib.oracle.entity.BasicEntity`.
3.  **Anotações de Coluna**: Utilize `@Column(position = X, fieldName = "NOME_COLUNA")` para mapear os campos, onde `position` é o índice da coluna no cursor de retorno.
4.  **Tratamento de Exceção**: Capture `PersistOracleException` e relance como `PersistenceException`.

## 🏗️ 3. Exemplo de Entity (Oracle)

```java
package br.com.bradesco.imob.exemplo.adapter.out.database.procedure.oracle.entity;

import br.com.bradesco.imob.lib.oracle.annotation.Column;
import br.com.bradesco.imob.lib.oracle.entity.BasicEntity;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ContratoEntity implements BasicEntity {

    @Column(position = 1, fieldName = "NR_CONTRATO")
    private BigDecimal numeroContrato;

    @Column(position = 2, fieldName = "SALDO_DEVEDOR")
    private BigDecimal saldoDevedor;

    @Column(position = 3, fieldName = "DT_VENCIMENTO")
    private LocalDate dataVencimento;
}
```

## 🛠️ 4. Padrões de Métodos Repository (CRUD)

### 🔍 Obter Instância Única
```java
public Optional<ContratoEntity> obterContrato(Long numeroContrato) {
    try {
        MapBuilder map = MapBuilder.build()
                .setProcedure(SCHEMA, P_SEL_RESUMO_CONTRATO)
                .set("IN_NR_CONTRATO", numeroContrato);
        return Optional.ofNullable(repository.find(map, ContratoEntity.class));
    } catch (PersistOracleException e) {
        throw new PersistenceException("Erro ao recuperar contrato", e);
    }
}
```

### 📋 Obter Lista de Objetos
```java
public List<ContratoEntity> obterListaContratos(Long numeroCpf) {
    try {
        MapBuilder map = MapBuilder.build()
                .setProcedure(SCHEMA, P_SEL_LISTA_CONTRATOS)
                .set("IN_NR_CPF", numeroCpf);
        return repository.findAny(map, ContratoEntity.class);
    } catch (PersistOracleException e) {
        throw new PersistenceException("Erro ao listar contratos", e);
    }
}
```

### 💾 Salvar (Incluir/Atualizar)
```java
public Object salvarContrato(ContratoEntity entity) {
    try {
        MapBuilder map = MapBuilder.build()
                .setProcedure(SCHEMA, P_INS_CONTRATO)
                .set("IN_NR_CONTRATO", entity.getNumeroContrato())
                .set("IN_SALDO_DEVEDOR", entity.getSaldoDevedor())
                .set("IN_DT_VENCIMENTO", entity.getDataVencimento());
        return repository.save(map);
    } catch (PersistOracleException e) {
        throw new PersistenceException("Erro ao salvar contrato", e);
    }
}
```

### 🗑️ Excluir
```java
public void excluirContrato(Long numeroContrato) {
    try {
        MapBuilder map = MapBuilder.build()
                .setProcedure(SCHEMA, P_DEL_CONTRATO)
                .set("IN_NR_CONTRATO", numeroContrato);
        repository.delete(map);
    } catch (PersistOracleException e) {
        throw new PersistenceException("Erro ao excluir contrato", e);
    }
}
```
