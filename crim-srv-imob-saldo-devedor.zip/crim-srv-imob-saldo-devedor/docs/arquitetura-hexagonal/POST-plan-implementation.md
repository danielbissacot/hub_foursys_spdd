# PRD: Implementação de Chamadas POST — Padrão Vila Moradia

## 1. Visão Geral
Define as regras obrigatórias para a implementação de operações de criação de recursos em microsserviços da Vila Moradia. O objetivo é garantir a integridade dos dados e a conformidade com as respostas HTTP de criação.

## 2. Padrões de Endpoint e Resposta

### 2.1 Criação de Recurso
Utilizado para submeter uma nova entidade ao sistema.

*   **Verbo HTTP**: `POST`
*   **Path**: `/{recurso}` (Ex: `/contratos`)
*   **Corpo da Requisição**: Objeto do tipo `Request` (DTO) via `@RequestBody`.
*   **Status de Sucesso**: `201 Created`
*   **Corpo da Resposta**: O objeto recém-criado convertido para o tipo `Response` (DTO).

## 3. Validação e Segurança
*   O uso de `@Valid` no `@RequestBody` é obrigatório para acionar as validações do Bean Validation no DTO de entrada.
*   Campos obrigatórios devem ser marcados com `@NotNull` e conter mensagens de erro padronizadas.

## 4. Fluxo de Implementação (Hexagonal)

O fluxo deve obrigatoriamente seguir as camadas:
1.  **Controller**: Recebe o `Request`, valida campos, converte `Request` -> `Model` via Mapper e invoca o `UseCase`.
2.  **UseCase**: Interface que define a entrada no hexágono.
3.  **Application Service**: Orquestra o fluxo de salvamento e regras de aplicação.
4.  **Domain Service**: Aplica regras de negócio.
5.  **Port Out**: Interface de saída para persistência.
6.  **Adapter Out (Persistence)**: Implementa a Port Out, salva no banco e mapeia o resultado salvo de volta para o Model.

### 4.1 Diagrama de Classes
```mermaid
classDiagram
    class DominioController {
        +salvarRecurso(DominioRequest) DominioResponse
    }
    class DominioSwagger {
        <<interface>>
        +salvarRecurso(...)
    }
    class DominioUseCase {
        <<interface>>
        +salvarRecurso(Dominio) Dominio
    }
    class DominioApplicationService {
        -DominioService domainService
        +salvarRecurso(Dominio) Dominio
    }
    class DominioService {
        -DominioPort port
        +salvarRecurso(Dominio) Dominio
    }
    class DominioPort {
        <<interface>>
        +salvar(Dominio) Dominio
    }
    class DominioPersistence {
        -DominioRepository repository
        +salvar(Dominio) Dominio
    }
    class DominioRepository {
        -LibRepository libRepository
        +salvarContrato(DominioEntity) Object
    }
    class LibRepository {
        <<Library>>
        +save(MapBuilder) Object
    }

    DominioController ..|> DominioSwagger
    DominioController --> DominioUseCase
    DominioApplicationService ..|> DominioUseCase
    DominioApplicationService --> DominioService
    DominioService --> DominioPort
    DominioPersistence ..|> DominioPort
    DominioPersistence --> DominioRepository
    DominioRepository --> LibRepository
```

### 4.2 Diagrama de Sequência
```mermaid
sequenceDiagram
    participant C as Cliente
    participant Ctrl as DominioController
    participant UC as DominioUseCase
    participant Ser as DominioApplicationService
    participant Dom as DominioService
    participant Prt as DominioPort
    participant Per as DominioPersistence
    participant Rep as DominioRepository
    participant Lib as LibRepository (imob-lib)
    participant DB as Banco de Dados

    C->>Ctrl: POST /api/v1/[recurso]
    activate Ctrl
    Ctrl->>Ctrl: Map Request para Model
    Ctrl->>UC: salvarRecurso(model)
    activate UC
    UC->>Ser: salvarRecurso(model)
    activate Ser
    Ser->>Dom: salvarRecurso(model)
    activate Dom
    Dom->>Prt: salvar(model)
    activate Prt
    Prt->>Per: salvar(model)
    activate Per
    Per->>Rep: salvarContrato(DominioEntity)
    activate Rep
    Rep->>Lib: save(MapBuilder)
    activate Lib
    Lib->>DB: insert/call procedure
    activate DB
    DB-->>Lib: Object/success
    deactivate DB
    Lib-->>Rep: Object/success
    deactivate Lib
    Rep-->>Per: Object/success
    deactivate Rep
    Per->>Per: Map Entity para Model
    Per-->>Prt: Dominio Model (Salvo)
    deactivate Per
    Prt-->>Dom: Dominio Model (Salvo)
    deactivate Prt
    Dom-->>Ser: Dominio Model (Salvo)
    deactivate Dom
    Ser-->>UC: Dominio Model (Salvo)
    deactivate Ser
    UC-->>Ctrl: Dominio Model (Salvo)
    deactivate UC
    Ctrl->>Ctrl: Map Model para Response
    Ctrl-->>C: 201 Created (DominioResponse)
    deactivate Ctrl
```

> [!IMPORTANT]
> **Diretrizes para Implementação de Banco de Dados (LibRepository e Entities)**:
> 1. A classe `LibRepository` não é genérica. Você **DEVE** injetar a implementação real fornecida pelas bibliotecas da fundação. Exemplo: `br.com.bradesco.imob.lib.db2.dao.RepositoryDB2`.
> 2. O mapeamento do banco de dados (Entity) **NÃO** deve ser um `record` simples. Ele deve ser uma classe anotada com `@Data`, deve obrigatoriamente estender `br.com.bradesco.imob.lib.db2.entity.BasicEntity` e seus atributos devem utilizar a anotação `@Column(fieldName = "NOME_COLUNA")`.
> 3. A chamada para a procedure deve utilizar o builder de comando SQL: `MapBuilder.build(TipoComandoSql.PROCEDURE).schemaName(SCHEMA).procedure(NOME_PROC).set("PARAM", valor)`.
> 4. As exceções de banco do tipo `Db2ResultConversionException` devem ser capturadas pelo Repository e relançadas como exceções de infraestrutura (ex: `PersistenceException` ou customizada da sua aplicação) para não vazar a biblioteca externa ao *Core* (Domain).




## 5. Exemplo de Referência (Baseado em Contrato)

### Controller
```java
@PostMapping("/contratos")
public ResponseEntity<ContratoResponse> salvarContrato(
        @RequestBody @Valid ContratoRequest request) {
    var contrato = ContratoMapper.INSTANCE.toContrato(request);
    var saved = contratoUseCase.salvarContrato(contrato);
    var response = ContratoMapper.INSTANCE.toResponse(saved);
    return ResponseEntity.status(HttpStatus.CREATED).body(response);
}
```

## 6. Diretrizes de Governança
*   Operações POST não devem ser idempotentes (múltiplas chamadas podem criar múltiplos recursos, a menos que haja regra de negócio de unicidade).
*   A URL do novo recurso criado pode ser opcionalmente retornada no Header `Location`.
