# PRD: Implementação de Chamadas PUT — Padrão Vila Moradia

## 1. Visão Geral
Define as regras obrigatórias para a implementação de operações de atualização total de recursos em microsserviços da Vila Moradia. Este padrão infere as regras de integridade do POST, mas com foco na modificação de recursos existentes.

## 2. Padrões de Endpoint e Resposta

### 2.1 Atualização de Recurso
Utilizado para substituir integralmente os dados de um recurso existente.

*   **Verbo HTTP**: `PUT`
*   **Path**: `/{recurso}/{id}` (Ex: `/contratos/{numeroContrato}`)
*   **Corpo da Requisição**: Objeto do tipo `Request` (DTO) contendo os novos dados do recurso.
*   **Status de Sucesso**: `200 OK` (se retornar o objeto atualizado) ou `204 No Content` (se não houver retorno).
*   **Status de Erro (Não Encontrado)**: `404 Not Found` (se o ID na URL não existir).

## 3. Diretrizes Técnicas
*   **Idempotência**: Diferente do POST, o PUT deve ser idempotente. Múltiplas chamadas idênticas devem resultar no mesmo estado final do recurso.
*   **Identificação**: O identificador do recurso deve vir pela URL (`@PathVariable`) e não apenas dentro do corpo do Request, garantindo a semântica REST.

## 4. Fluxo de Implementação (Hexagonal)

O fluxo deve obrigatoriamente seguir as camadas:
1.  **Controller**: Valida o ID da URL e o corpo da requisição. Mapeia para `Model` e chama o `UseCase`.
2.  **UseCase**: Interface de entrada no hexágono.
3.  **Application Service**: Implementação do `UseCase`. Orquestra o fluxo de atualização.
4.  **Domain Service**: Aplica regras de negócio para a modificação e orquestra a chamada para a porta.
5.  **Port Out**: Interface de saída para busca e atualização.
6.  **Adapter Out (Persistence)**: Implementa a `Port Out`, realiza o `merge/update` na base de dados e mapeia de volta para o `Model`.

### 4.1 Diagrama de Classes
```mermaid
classDiagram
    class DominioController {
        +atualizarRecurso(id, DominioRequest) DominioResponse
    }
    class DominioSwagger {
        <<interface>>
        +atualizarRecurso(...)
    }
    class DominioUseCase {
        <<interface>>
        +atualizarRecurso(id, Dominio) Dominio
    }
    class DominioApplicationService {
        -DominioService service
        +atualizarRecurso(id, Dominio) Dominio
    }
    class DominioService {
        -DominioPort port
        +atualizarRecurso(id, Dominio) Dominio
    }
    class DominioPort {
        <<interface>>
        +buscarPorId(id) Dominio
        +atualizar(Dominio) Dominio
    }
    class DominioPersistence {
        -DominioRepository repository
        +atualizar(Dominio) Dominio
    }
    class DominioRepository {
        -LibRepository libRepository
        +obterPorId(id) DominioEntity
        +salvarContrato(DominioEntity) Object
    }
    class LibRepository {
        <<Library>>
        +find(MapBuilder, Class)
        +save(MapBuilder) Object
    }

    DominioController ..|> DominioSwagger
    DominioController --> DominioUseCase
    DominioApplicationService ..|> DominioUseCase
    DominioApplicationService --> DominioService
    DominioService --> DominioPort
    DominioPersistence ..|> DominioPort
    DominioPersistence --> DominioRepository
    DominioRepository --> LibRepository
```

### 4.2 Diagrama de Sequência
```mermaid
sequenceDiagram
    participant C as Cliente
    participant Ctrl as DominioController
    participant UC as DominioUseCase
    participant Ser as DominioApplicationService
    participant Prt as DominioPort
    participant Per as DominioPersistence
    participant Rep as DominioRepository
    participant Lib as LibRepository (imob-lib)
    participant DB as Banco de Dados

    C->>Ctrl: PUT /api/v1/[recurso]/{id}
    activate Ctrl
    Ctrl->>Ctrl: Map Request para Model
    Ctrl->>UC: atualizarRecurso(id, model)
    activate UC
    UC->>Ser: atualizarRecurso(id, model)
    activate Ser
    Ser->>Dom: atualizarRecurso(id, model)
    activate Dom
    Dom->>Prt: buscarPorId(id)
    activate Prt
    Prt->>Per: buscarPorId(id)
    activate Per
    Per->>Rep: obterPorId(id)
    activate Rep
    Rep-->>Per: DominioExistente
    deactivate Rep
    Per-->>Prt: DominioExistente
    deactivate Per
    Prt-->>Dom: DominioExistente
    deactivate Prt
    Dom->>Prt: atualizar(model)
    activate Prt
    Prt->>Per: atualizar(model)
    activate Per
    Per->>Rep: salvarContrato(DominioEntity)
    activate Rep
    Rep->>Lib: save(MapBuilder)
    activate Lib
    Lib->>DB: update/call procedure
    activate DB
    DB-->>Lib: Object/success
    deactivate DB
    Lib-->>Rep: Object/success
    deactivate Lib
    Rep-->>Per: Object/success
    deactivate Rep
    Per->>Per: Map Entity para Model
    Per-->>Prt: Dominio Model (Atualizado)
    deactivate Per
    Prt-->>Dom: Dominio Model (Atualizado)
    deactivate Prt
    Dom-->>Ser: Dominio Model (Atualizado)
    deactivate Dom
    Ser-->>UC: Dominio Model (Atualizado)
    deactivate Ser
    UC-->>Ctrl: Dominio Model (Atualizado)
    deactivate UC
    Ctrl->>Ctrl: Map Model para Response
    Ctrl-->>C: 200 OK (DominioResponse)
    deactivate Ctrl
```

> [!IMPORTANT]
> **Diretrizes para Implementação de Banco de Dados (LibRepository e Entities)**:
> 1. A classe `LibRepository` não é genérica. Você **DEVE** injetar a implementação real fornecida pelas bibliotecas da fundação. Exemplo: `br.com.bradesco.imob.lib.db2.dao.RepositoryDB2`.
> 2. O mapeamento do banco de dados (Entity) **NÃO** deve ser um `record` simples. Ele deve ser uma classe anotada com `@Data`, deve obrigatoriamente estender `br.com.bradesco.imob.lib.db2.entity.BasicEntity` e seus atributos devem utilizar a anotação `@Column(fieldName = "NOME_COLUNA")`.
> 3. A chamada para a procedure deve utilizar o builder de comando SQL: `MapBuilder.build(TipoComandoSql.PROCEDURE).schemaName(SCHEMA).procedure(NOME_PROC).set("PARAM", valor)`.
> 4. As exceções de banco do tipo `Db2ResultConversionException` devem ser capturadas pelo Repository e relançadas como exceções de infraestrutura (ex: `PersistenceException` ou customizada da sua aplicação) para não vazar a biblioteca externa ao *Core* (Domain).


## 5. Exemplo de Referência (Inferido)

### Controller
```java
@PutMapping("/contratos/{numeroContrato}")
public ResponseEntity<ContratoResponse> atualizarContrato(
        @PathVariable BigDecimal numeroContrato,
        @RequestBody @Valid ContratoRequest request) {
    var contrato = ContratoMapper.INSTANCE.toContrato(request);
    contrato.setNumeroContrato(numeroContrato); // Vincula ID da URL
    var updated = contratoUseCase.atualizarContrato(contrato);
    var response = ContratoMapper.INSTANCE.toResponse(updated);
    return ResponseEntity.ok(response);
}
```

## 6. Diretrizes de Governança
*   Não utilize PUT para atualizações parciais de campos (para isso, utilize PATCH).
*   Certifique-se de que validações de auditoria (data de alteração, usuário) sejam aplicadas no Domain Service.
