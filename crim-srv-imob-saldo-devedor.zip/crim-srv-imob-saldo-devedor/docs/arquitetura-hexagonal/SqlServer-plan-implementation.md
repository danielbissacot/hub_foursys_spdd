# 🛠️ Diretrizes de Implementação: SQL Server (Stored Procedures)

Este documento descreve o padrão obrigatório para acesso a dados no banco de dados **SQL Server** utilizando a biblioteca corporativa `imob-lib-sqlserver`.

## 📦 1. Dependência Necessária

Certifique-se de que a biblioteca está presente no seu `pom.xml`:

```xml
<dependency>
    <groupId>br.com.bradesco.imob</groupId>
    <artifactId>imob-lib-sqlserver</artifactId>
    <version>${imob-lib-sqlserver.version}</version>
</dependency>
```

## 📋 2. Regras de Ouro (SQL Server)

1.  **Injeção do Repository**: Utilize a classe `br.com.bradesco.imob.lib.sqlserver.dao.RepositorySql`.
2.  **Mapeamento de Entidade**: As classes `Entity` **DEVEM** estender `br.com.bradesco.imob.lib.sqlserver.entity.BasicSqlEntity`.
3.  **Anotações de Coluna**: Utilize `@Column(fieldName = "NOME_COLUNA")` para mapear os campos do ResultSet.
4.  **Tratamento de Exceção**: Capture `SqlServerDataException` e relance como `PersistenceException`.

## 🏗️ 3. Exemplo de Entity (SQL Server)

```java
package br.com.bradesco.imob.exemplo.adapter.out.database.procedure.sqlserver.entity;

import br.com.bradesco.imob.lib.sqlserver.annotation.Column;
import br.com.bradesco.imob.lib.sqlserver.entity.BasicSqlEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false)
public class ContratoEntity extends BasicSqlEntity {

    @Column(fieldName = "NR_CONTRATO")
    private BigDecimal numeroContrato;

    @Column(fieldName = "SALDO_DEVEDOR")
    private BigDecimal saldoDevedor;

    @Column(fieldName = "DT_VENCIMENTO")
    private LocalDate dataVencimento;
}
```

## 🛠️ 4. Padrões de Métodos Repository (CRUD)

### 🔍 Obter Instância Única
```java
public Optional<ContratoEntity> obterContrato(Long numeroContrato) {
    try {
        MapBuilder map = MapBuilder
                .build(TipoComandoSql.PROCEDURE)
                .schemaName(SCHEMA)
                .procedure(P_SEL_RESUMO_CONTRATO)
                .set("IN_NR_CONTRATO", numeroContrato);
        return repository.findOne(map, ContratoEntity.class);
    } catch (SqlServerDataException e) {
        throw new PersistenceException("Erro ao recuperar contrato", e);
    }
}
```

### 📋 Obter Lista de Objetos
```java
public List<ContratoEntity> obterListaContratos(Long numeroCpf) {
    try {
        MapBuilder map = MapBuilder
                .build(TipoComandoSql.PROCEDURE)
                .schemaName(SCHEMA)
                .procedure(P_SEL_LISTA_CONTRATOS)
                .set("IN_NR_CPF", numeroCpf);
        return repository.findAny(map, ContratoEntity.class);
    } catch (SqlServerDataException e) {
        throw new PersistenceException("Erro ao listar contratos", e);
    }
}
```

### 💾 Salvar (Incluir/Atualizar)
```java
public BigDecimal salvarContrato(ContratoEntity entity) {
    try {
        MapBuilder map = MapBuilder
                .build(TipoComandoSql.PROCEDURE)
                .schemaName(SCHEMA)
                .procedure(P_INS_CONTRATO)
                .setEntity(entity);
        return repository.save(map);
    } catch (SqlServerDataException e) {
        throw new PersistenceException("Erro ao salvar contrato", e);
    }
}
```

### 🗑️ Excluir
```java
public void excluirContrato(Long numeroContrato) {
    try {
        MapBuilder map = MapBuilder
                .build(TipoComandoSql.PROCEDURE)
                .schemaName(SCHEMA)
                .procedure(P_DEL_CONTRATO)
                .set("IN_NR_CONTRATO", numeroContrato);
        repository.delete(map);
    } catch (SqlServerDataException e) {
        throw new PersistenceException("Erro ao excluir contrato", e);
    }
}
```
