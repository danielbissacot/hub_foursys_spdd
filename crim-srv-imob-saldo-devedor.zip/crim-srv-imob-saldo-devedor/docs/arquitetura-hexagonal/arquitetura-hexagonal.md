# PRD: Padronização de Arquitetura Hexagonal — Vila Moradia

## 1. Visão Geral e Propósito

Este documento estabelece as **diretrizes obrigatórias** de Arquitetura Hexagonal (Ports and Adapters) para todos os microsserviços desenvolvidos na iniciativa **Vila Moradia**. Esta padronização é a única fonte de verdade (PRD) para a estruturação de projetos, visando garantir a independência total do núcleo de negócio frente a tecnologias de infraestrutura, bancos de dados e frameworks.

**A conformidade com estas diretrizes é mandatória para todos os projetos SRV (Service) da Vila Moradia.**

## 2. Princípios Fundamentais (Regras de Ouro)

1.  **Independência de Framework**: O núcleo da aplicação (`application/`) não deve conhecer frameworks (Spring, Hibernate, etc.). Exceções são permitidas apenas para anotações de injeção de dependência e especificações Java (JSRs).
2.  **Inversão de Dependências**: Camadas externas (`adapter/`) devem depender das interfaces definidas no núcleo (`port/`). O núcleo **nunca** deve depender de classes concretas dos adaptadores.
3.  **Isolamento de Erros**: Exceções técnicas de infraestrutura (SQLExceptions, FeignExceptions) devem ser capturadas nos adaptadores e traduzidas para exceções de negócio ou de aplicação antes de cruzarem a fronteira do hexágono.
4.  **Mapeamento Obrigatório**: É terminantemente proibido o vazamento de entidades de banco de dados (`Entity`) ou DTOs de interface para o modelo de domínio. A conversão via `Mappers` é obrigatória em cada entrada e saída do hexágono.
5.  **Clean Code e Práticas de Engenharia**: Todo o desenvolvimento deve obedecer à filosofia do código limpo ("Clean Code", proposto por Robert C. Martin). Para atingir essa legibilidade e manutenibilidade, a base de código **DEVE** observar os seguintes princípios:
    - **SOLID**: Aplicar a responsabilidade única, o aberto/fechado, a substituição de Liskov, a segregação de interfaces e a inversão de dependência (espinha dorsal da arquitetura hexagonal).
    - **DRY (Don't Repeat Yourself)**: Mitigar duplicações lógicas não essenciais sem comprometer a clareza e o baixo acoplamento.
    - **KISS (Keep It Simple, Stupid)**: Solucionar os problemas sempre da maneira mais simples possível, sem complexidade acidental (Overengineering).
    - **YAGNI (You Aren't Gonna Need It)**: Não antecipe implementações, contratos ou portas baseadas em "achismos" para o futuro. Construa apenas o escopo que cobre a estória atual.
    - **Higiene de Código (Código Morto)**: É mandatória a remoção de atributos, variáveis locais, métodos privados ou constantes que não possuam uso efetivo no sistema. Da mesma forma, **imports não utilizados** devem ser eliminados para manter o código limpo e evitar acoplamento fantasma.
6.  **Convenções de Nomenclatura Java**: Ao criar classes, métodos e atributos, **DEVE-SE** seguir os padrões de convenção Java. Por exemplo: Classes DEVEM ser substantivos, métodos DEVEM ser verbos, variáveis devem ter nomes descritivos. Padrões como `PascalCase` para classes/interfaces e `camelCase` para métodos/variáveis são obrigatórios.

## 3. Estrutura Obrigatória de Pacotes

Todos os projetos devem seguir rigorosamente a hierarquia de pacotes abaixo:

```text
src/main/java/br/com/bradesco/imob/vila/moradia/[projeto]/
├── Application.java                           # Start da aplicação contextualmente
├── adapter/                                   # CAMADA DE ADAPTADORES (Mundo Externo)
│   ├── in/                                    # Adaptadores de Entrada (Driving)
│   │   ├── controller/                        # REST Controllers (Versionados por sub-package v1, v2)
│   │   ├── request/                           # DTOs de entrada (Input Data)
│   │   ├── response/                          # DTOs de saída (Output Data)
│   │   ├── dto/                               # DTOs genéricos ou auxiliares
│   │   ├── mapper/                            # Mappers REST (DTO ↔ Model)
│   │   ├── swagger/                           # Configurações e anotações OpenAPI/Swagger
│   │   └── exception/                         # Tratamento global de exceções HTTP (Advice)
│   └── out/                                   # Adaptadores de Saída (Driven)
│       ├── database/                          # Camada de Persistência
│       │   ├── persistence/                   # Implementações das Outbound Ports (Fachadas)
│       │   ├── jpa/                           # Repositórios e Entidades Spring Data JPA
│       │   └── procedure/                     # Acesso via Stored Procedures
│       │       └── [acesso]/                  # db2, oracle ou sqlserver
│       │           ├── entity/                # Classes de representação técnica da Procedure
│       │           ├── mapper/                # Conversores entre Entity técnica e Model
│       │           └── repository/            # Camada técnica de execução da Procedure (Bind/Execução)
│       └── client/                            # Chamadas REST externas (Feign, RestClient)
│           ├── rest/                          # Interfaces/Clients de contrato REST
│           ├── response/                      # DTOs de resposta da API externa
│           └── exception/                     # Tratamento de erros específicos de integração
├── application/                               # CAMADA DE APLICAÇÃO (O Hexágono/Core)
│   ├── port/                                  # Definição de Contratos (Interfaces)
│   │   ├── in/                                # Inbound Ports (Interfaces de Caso de Uso)
│   │   └── out/                               # Outbound Ports (Interfaces de Serviço Externo/DB)
│   ├── usecase/                               # Implementação da Orquestração de Fluxo
│   ├── service/                               # Lógica de Negócio Pura e Determinística
│   ├── model/                                 # Modelos de Domínio (Preferencialmente Records)
│   └── exception/                             # Exceções Customizadas da Aplicação/Negócio
└── utils/                                     # Componentes Transversais Utilitários
```

## 4. Padrões de Nomenclatura (Sufixos Obrigatórios)

Para garantir a legibilidade e a automação de testes de arquitetura (ex: ArchUnit), os componentes devem seguir os seguintes sufixos:

| Componente | Camada | Sufixo | Exemplo |
|:---|:---|:---|:---|
| **Controller REST** | Adapter In | `Controller` | `ContratoController` |
| **Mapper de Interface** | Adapter In | `RestMapper` | `ContratoRestMapper` |
| **Interface de Entrada** | Port In | `UseCase` | `ContratoUseCase` |
| **Orquestrador de Fluxo** | Application | `ApplicationService` | `ContratoApplicationService` |
| **Lógica de Negócio** | Application | `Service` | `ContratoService` |
| **Modelo de Domínio** | Application | (Sem Sufixo) | `Contrato` |
| **Interface de Saída** | Port Out | `Port` | `ContratoPort` |
| **Impl. de Persistência** | Adapter Out | `Persistence` | `ContratoPersistence` |
| **Implementação de API** | Adapter Out | `Client` | `ServiceNowClient` |
| **Entidade de Dados** | Adapter Out | `Entity` | `ContratoEntity` |

> **Atenção (Regra do ArchUnit)**: É crucial respeitar a estrutura de pastas separando os `DTOs` e `Mappers` nos pacotes irmãos (`adapter/in/request/`, `adapter/in/mapper/`, etc.) e **NÃO** como sub-pacotes de `adapter/in/controller/`. A biblioteca de *Code Review* valida que **todas** as classes dentro do pacote `..adapter.in.controller..` terminem com o sufixo `Controller`. Se um `DTO` for posicionado neste diretório, o build quebrará!

> **Diretiva de Segurança (Mandatória)**: Todas as classes Controller **DEVEM** conter a anotação `@Secured` (`br.com.bradesco.imob.lib.common.security.annotion.Secured`). Esta anotação força a interceptação e validação obrigatória do token JWT (passado no Header da requisição) através da biblioteca `imob-lib-common`. Sem esta anotação, o endpoint fica exposto sem autenticação corporativa.

## 5. Fluxo de Execução Padronizado

O processamento de qualquer requisição **deve** seguir o fluxo linear abaixo:

1.  **Inbound Adapter**: Captura o estímulo (HTTP/Mensageria), valida o contrato sintático e mapeia DTO -> Model.
2.  **Inbound Port**: Interface que define a entrada no hexágono.
3.  **Application Service (UseCase Implementation)**: Recebe o Model e orquestra a chamada de um ou mais Domain Services. **NUNCA** deve injetar ou invocar Outbound Ports diretamente.
4.  **Domain Service**: Executa regras de cálculo, validações de estado e lógica de negócio pura. É o **único componente** autorizado a invocar as Outbound Ports.
5.  **Outbound Port**: Interface que define a necessidade de dados ou integração externa.
6.  **Outbound Adapter**: Implementa a integração técnica (SQL, Client REST), captura falhas de infraestrutura e mapeia o resultado de volta para Model.

## 6. Documentação de Design Obrigatória

Durante a fase de *Design* (geração do arquivo `design.md`), é **obrigatória** a inclusão de diagramas visuais (utilizando Mermaid) para garantir o pleno entendimento da solução. Todo documento de design gerado para componentes da Vila Moradia deve conter obrigatoriamente:
1. **Diagrama de Sequência (`sequenceDiagram`)**: Detalhando o fluxo da requisição passo a passo (ex: desde o `Controller` até a persistência no banco de dados, incluindo as devoluções de tipo e *Optionals*).
2. **Diagrama de Classes (`classDiagram`)**: Mapeando todos os componentes da arquitetura hexagonal, as interfaces (`Ports`), suas injeções de dependências e assinaturas de métodos.

## 7. Práticas de Testes Isolados

Dada a natureza fragmentada de dependências da Vila Moradia (tais como Redis, DB2, Oracle), os testes das camadas devem seguir metodologias de isolamento para evitar falhas de contexto do Spring (ex: `NoSuchBeanDefinitionException`).

### 7.1 Classes Obrigatórias para Testes Unitários

Para garantir a qualidade e manutenibilidade do código, **TODAS** as funcionalidades devem conter testes unitários para as seguintes classes:

| Camada | Classe | Tipo de Teste | Frameworks Recomendados |
|--------|--------|---------------|------------------------|
| **Adapter In** | `*Controller` | Unit Test | `MockMvcBuilders.standaloneSetup()` + Mockito |
| **Adapter In** | `*Persistence` (Outbound) | Unit Test | Mockito `@ExtendWith(MockitoExtension.class)` |
| **Core (Application)** | `*ApplicationService` | Unit Test | Mockito `@ExtendWith(MockitoExtension.class)` |
| **Core (Application)** | `*Service` (Domain) | Unit Test | Mockito `@ExtendWith(MockitoExtension.class)` |
| **Adapter Out** | `*Repository` | Unit Test | Mockito (incluir teste de exceção) |

### 7.2 Regras de Teste

1. **Testes de Controller (Adapter In)**: Recomendado o uso do `MockMvcBuilders.standaloneSetup(controller)` com injeção de dependências Mockito (via `@InjectMocks` e `@Mock`), ignorando as anotações completas de contexto como `@WebMvcTest`. Isto garante a imunidade a interdependências da biblioteca pai `crim-lib-imob-parent`.
2. **Testes do Núcleo (Core)**: Classes `ApplicationService` e `Service` não devem usar contexto Spring (`@SpringBootTest`). Devem ser simples unit tests utilizando `@ExtendWith(MockitoExtension.class)`.
3. **Testes de Repository**: Devem incluir cenários de exceção (ex: `Db2ResultConversionException`) para garantir tratamento adequado de erros.
4. **Testes de Persistence**: Devem testar a conversão de Entity para Model usando Mappers MapStruct.
5. **Cobertura**: É recomendada cobertura de testes para todos os métodos públicos das classes listadas acima.

## 8. ✅ Checklist de Configuração Obrigatória do Projeto (`pom.xml` e `application-*.yml`)

> [!CAUTION]
> **Esta é a etapa mais esquecida e que causa falhas de compilação e de runtime!** Antes de iniciar qualquer implementação, **VERIFIQUE** se os itens abaixo estão presentes no projeto. O não cumprimento bloqueia o build e gera erros silenciosos em produção.

O arquivo **[`configuracao.md`](./configuracao.md)** é a fonte de verdade para todas as configurações de infraestrutura. As regras a seguir são um resumo do que **DEVE** ser validado antes de implementar qualquer funcionalidade nova:

### 📦 `pom.xml` — Dependências e Plugins

| Recurso utilizado | Ação obrigatória no `pom.xml` |
| :--- | :--- |
| **DB2** | Adicionar dependência `imob-lib-db2` |
| **Oracle** | Adicionar dependência `imob-lib-oracle` |
| **SQL Server** | Adicionar dependência `imob-lib-sqlserver` |
| **Redis** | Adicionar dependência `imob-lib-redis` |
| **MapStruct (qualquer Mapper)** | Declarar o `maven-compiler-plugin` com `annotationProcessorPaths` para `mapstruct-processor` |

> **Por que o MapStruct falha silenciosamente?** Sem o `maven-compiler-plugin` configurado, o MapStruct gera as classes de implementação mas o compilador não as enxerga, causando `Error: Unresolved compilation problems` em runtime. Consulte o exemplo completo em [`configuracao.md`](./configuracao.md).

### 🛠️ `application-{DEV,HOM,PRD}.yml` — Parâmetros de Conexão

Os parâmetros de conexão com banco de dados e Redis **DEVEM** existir nos três profiles. Consulte [`configuracao.md`](./configuracao.md) para os templates completos de:

- **Redis** (`spring.data.redis.*`)
- **DB2** (`spring.db2.datasource.*`)
- **Oracle** (`spring.oracle.datasource.*`)
- **SQL Server** (`spring.sqlserver.datasource.*`)

> [!IMPORTANT]
> Os parâmetros entre `${}` são variáveis que **DEVEM** estar definidas no arquivo `values.yaml` do artefato de configuração `{crim-srv-imob-*}-config` nas branches `sandbox` (DSV), `staging` (HOM) e `production` (PRD).

## 9. Documentação de Código (JavaDoc)

A documentação técnica do código deve ser mantida via JavaDoc em todas as classes e métodos públicos/protegidos, seguindo os princípios de **Clean Documentation**:

1.  **Não declare o óbvio**: Evite comentários que apenas repetem o nome do método ou classe.
2.  **Foco no Propósito**: Explique *o que* o componente faz ou *qual* responsabilidade ele assume no hexágono.
3.  **Sintaxe Padronizada**:
    *   **Classes**: Descrição concisa da responsabilidade.
    *   **Métodos**: Descrição do comportamento, `@param` para parâmetros não óbvios, `@return` para o significado do retorno e `@throws` para exceções de negócio/infraestrutura lançadas.
4.  **Linguagem**: A documentação deve ser escrita em **Português (Brasil)** para manter a consistência com os requisitos e termos de negócio da Vila Moradia.

## 10. Implementação de Acesso a Dados (Procedures)

A persistência de dados na Vila Moradia prioriza o uso de **Stored Procedures** para garantir a performance e a segurança transacional. Para cada banco de dados suportado, existem diretivas específicas e exemplos de implementação de métodos CRUD e mapeamento de entidades técnicas.

As diretrizes detalhadas por banco de dados encontram-se nos documentos abaixo:

- 💾 **[Diretrizes DB2](./DB2-plan-implementation.md)**
- 💾 **[Diretrizes Oracle](./Oracle-plan-implementation.md)**
- 💾 **[Diretrizes SQL Server](./SqlServer-plan-implementation.md)**

### 📋 Padrão de Métodos em Repository (Exemplos)

Independentemente do banco de dados, o `Repository` técnico da camada `adapter/out/database/procedure/[db]/repository/` deve seguir estas assinaturas:

| Operação | Método Padrão | Retorno |
| :--- | :--- | :--- |
| **Consulta Única** | `obter[Dominio]` | `Optional<Entity>` |
| **Consulta Lista** | `obterLista[Dominio]` | `List<Entity>` |
| **Inclusão/Atualização** | `salvar[Dominio]` | `BigDecimal` ou `Object` |
| **Exclusão** | `excluir[Dominio]` | `void` |

## 11. Governança e Evolução

Qualquer desvio deste padrão deve ser formalmente justificado e aprovado pela Arquitetura Vila Moradia. Este documento será revisado periodicamente para incluir novos padrões (Ex: Mensageria/Kafka) e melhorias contínuas baseadas nos microsserviços de referência.

---
**Status:** ATIVO  
**Responsável:** Arquitetura Vila Moradia  
**Data da Última Atualização:** 24/04/2026