# Parametrização e Dependências - Microserviços Vila Moradia

Abaixo, segue a relação de dependências que devem existir no arquivo pom.xml do projetos dos microserviços da Vila Moradia.

**ATENÇÃO:** As dependências devem ser incluídas somente se o projeto utilizar o recurso [DB2, ORACLE, SQLSERVER ou REDIS] e se ainda não existirem no arquivo pom.xml do projeto.

```xml
<dependency>
	<groupId>br.com.bradesco.imob</groupId>
	<artifactId>imob-lib-redis</artifactId>
</dependency>
<dependency>
	<groupId>br.com.bradesco.imob</groupId>
	<artifactId>imob-lib-db2</artifactId>
</dependency>
<dependency>
	<groupId>br.com.bradesco.imob</groupId>
	<artifactId>imob-lib-oracle</artifactId>
</dependency>
<dependency>
	<groupId>br.com.bradesco.imob</groupId>
	<artifactId>imob-lib-sqlserver</artifactId>
</dependency>
```

### 🛠️ Configuração do MapStruct (Plugin de Compilação)

Caso o projeto utilize o **MapStruct** para conversão de DTOs e Entities, é **OBRIGATÓRIA** a declaração do `maven-compiler-plugin` com os `annotationProcessorPaths` no arquivo `pom.xml`. Se essa configuração for omitida, o MapStruct não gerará as classes de implementação em tempo de compilação, causando falhas graves como `java.lang.Error: Unresolved compilation problems`.

> [!IMPORTANT]
> **O Lombok DEVE ser declarado antes do MapStruct** nos `annotationProcessorPaths`. Isso garante que os getters/setters do `@Data` sejam gerados antes que o MapStruct tente usá-los. Se o Lombok for omitido, os setters não serão encontrados em tempo de compilação.

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <configuration>
        <annotationProcessorPaths>
            <!-- Lombok DEVE vir primeiro para gerar getters/setters antes do MapStruct -->
            <path>
                <groupId>org.projectlombok</groupId>
                <artifactId>lombok</artifactId>
                <version>${lombok.version}</version>
            </path>
            <!-- MapStruct gera as implementações dos Mappers -->
            <path>
                <groupId>org.mapstruct</groupId>
                <artifactId>mapstruct-processor</artifactId>
                <version>${mapstruct.version}</version>
            </path>
        </annotationProcessorPaths>
    </configuration>
</plugin>
```

A mesma lógica se aplica para os arquivos de properties application-{DEV/HOM/PRD}. Os parametros DEVEM ser incluídos somente SE já não existirem nos arquivos application-{DEV/HOM/PRD}.

> [!IMPORTANT]
> **Regra de Merge da Chave `spring`**: Os arquivos `application-*.yml` **já possuem** uma chave `spring` raiz com configurações existentes (jackson, ssl, config, etc.). **NUNCA** crie um segundo bloco `spring:` separado — isso gera o erro `Map keys must be unique` no parser YAML e corrompe as configurações do ambiente.
>
> **Regra de Ouro**: Se a chave `spring` **já existir** no arquivo, adicione as novas propriedades (`data.redis`, `db2`, `oracle`, `sqlserver`) como **sub-chaves dentro do bloco `spring` existente**, preservando a indentação e o contexto. Veja o exemplo correto abaixo:
>
> ```yaml
> # ✅ CORRETO — Merge sob a chave spring existente
> spring:
>   jackson:          # <-- configuração já existente
>     time-zone: America/Sao_Paulo
>   data:             # <-- nova propriedade adicionada dentro do spring existente
>     redis:
>       host: ${REDIS_HOST:localhost}
>   db2:              # <-- nova propriedade adicionada dentro do spring existente
>     datasource:
>       url: jdbc:db2://...
>
> # ❌ ERRADO — Cria chave duplicada, quebrando o YAML
> spring:
>   jackson:
>     time-zone: America/Sao_Paulo
>
> spring:             # <-- DUPLICADO! Causa "Map keys must be unique"
>   data:
>     redis:
>       host: ${REDIS_HOST:localhost}
> ```

** Nota:
## ATENÇÃO (Apenas uma informação): Os parametros entre cochetes DEVEM estar definidos no arquivo values.yaml no artefato {crim-srv-imob-*}-config, nas branch sandbox(DSV), staging (HOM) e production(PRD).


### application-DEV.yml

```yaml
# Parametrização para o Redis =================================================
spring:
  data:
    redis:
      # Endereço do servidor Redis (padrão: localhost)
      host: ${REDIS_HOST:localhost}
      # Porta do servidor Redis (padrão: 6379)
      port: ${REDIS_PORT:6379}
      # Senha para autenticação no Redis (padrão: vazio)
      password: ${REDIS_PWD:}
      # Tempo limite (timeout) para operações com o Redis em segundos.
      timeout: ${REDIS_TIMEOUT:600}
      # Pacote base para o escaneamento dos repositórios Redis
      repository-package: br.com.bradesco.imob.*
      # Habilita a conexão SSL com o Redis (padrão: false)
      sslEnabled: ${REDIS_SSL:false}

# Parametrização dos Bancos de Dados =============================================
spring:
  oracle:
    datasource:
      # TODO: Deve ser substituído por parametros
      oracleHost: 10.194.66.247
      oraclePort: 1521
      oracleServiceName: crimti
      oracleUser: crimpf10
      oraclePass: pa45612
      oracleInitPoolSize: 2
      oracleMinPoolSize: 1
      oracleMaxPoolSize: 10

spring:
  db2:
    datasource:
      url: jdbc:db2://172.20.211.100:50011/DCIRD000
      driver-class-name: com.ibm.db2.jcc.DB2Driver
      username: ${adqemp-db2-crim-usr-00001:userDb2}
      password: ${adqemp-db2-crim-pwd-00001:pwdDb2}
      connectionPoolInitialSize: 2	

spring:	
  sqlserver:
    datasource:
       url: jdbc:sqlserver://${SQLSERVER_HOST:mssqlazudvbracrim001.database.windows.net\sqlcrimdb001imob}:${SQLSERVER_PORT:1433};database=${SQLSERVER_DB:sqlcrimdb001imob};encrypt=true;trustServerCertificate=true
       username: ${SQLSERVER_USER:dusrbdcrim01}
       password: ${SQLSERVER_PASS:Ds_dusrbd_crim01}
       driver-class-name: com.microsoft.sqlserver.jdbc.SQLServerDriver
       connectionPoolInitialSize: 2	
```

---

### application-HOM.yml

```yaml
# Parametrização para o Redis =================================================
spring:
  data:
    redis:
      # Endereço do servidor Redis (padrão: localhost)
      host: ${REDIS_HOST:localhost}
      # Porta do servidor Redis (padrão: 6379)
      port: ${REDIS_PORT:6379}
      # Senha para autenticação no Redis (padrão: vazio)
      password: ${REDIS_PWD:}
      # Tempo limite (timeout) para operações com o Redis em segundos.
      timeout: ${REDIS_TIMEOUT:600}
      # Pacote base para o escaneamento dos repositórios Redis
      repository-package: br.com.bradesco.imob.*
      # Habilita a conexão SSL com o Redis (padrão: false)
      sslEnabled: ${REDIS_SSL:false}

# Parametrização dos Bancos de Dados =============================================
#Definição dos parametros de acesso aos Bancos de Dados

#Banco de Dados: ORACLE
spring:
  oracle:
    datasource:
      # TODO: Deve ser substituido por parametros
      oracleHost: 10.194.66.247
      oraclePort: 1521
      oracleServiceName: crimti
      oracleUser: crimpf10
      oraclePass: pa45612
      oracleInitPoolSize: 2
      oracleMinPoolSize: 1
      oracleMaxPoolSize: 10

#Banco de Dados: DB2
spring:
  db2:
    datasource:
      url: jdbc:db2://172.20.211.100:50011/DCIRD000
      driver-class-name: com.ibm.db2.jcc.DB2Driver
      username: ${adqemp-db2-crim-usr-00001}
      password: ${adqemp-db2-crim-pwd-00001}
      connectionPoolInitialSize: 2

#Banco de Dados: SQLSERVER
spring:
  sqlserver:
    datasource:
      url: jdbc:sqlserver://${SQLSERVER_HOST}:${SQLSERVER_PORT};database=${SQLSERVER_DB};encrypt=true;trustServerCertificate=true
      username: ${SQLSERVER_USER}
      password: ${SQLSERVER_PASS}
      driver-class-name: com.microsoft.sqlserver.jdbc.SQLServerDriver
      connectionPoolInitialSize: 2
```

---

### application-PRD.yml

```yaml
# Parametrização para o Redis =================================================
spring:
  data:
    redis:
      # Endereço do servidor Redis (padrão: localhost)
      host: ${REDIS_HOST:localhost}
      # Porta do servidor Redis (padrão: 6379)
      port: ${REDIS_PORT:6379}
      # Senha para autenticação no Redis (padrão: vazio)
      password: ${REDIS_PWD:}
      # Tempo limite (timeout) para operações com o Redis em segundos.
      timeout: ${REDIS_TIMEOUT:600}
      # Pacote base para o escaneamento dos repositórios Redis
      repository-package: br.com.bradesco.imob.*
      # Habilita a conexão SSL com o Redis (padrão: false)
      sslEnabled: ${REDIS_SSL:false}

# Parametrização dos Bancos de Dados =============================================
#Definição dos parametros de acesso aos Bancos de Dados

#Banco de Dados: ORACLE
spring:
  oracle:
    datasource: # TODO: Deve ser substituido por parametros
      oracleHost: mz-cl-bd-590a.corp.bradesco.com.br
      oraclePort: 1521
      oracleServiceName: crim
      oracleUser: ${adqemp-oracle-crim-usr-00001:userOracle}
      oraclePass: ${adqemp-oracle-crim-pwd-00001:pwdOracle}
      oracleInitPoolSize: 2
      oracleMinPoolSize: 1
      oracleMaxPoolSize: 10

#Banco de Dados: DB2
spring:
  db2:
    datasource:
      url: jdbc:db2://10.198.5.93:50012/DCIRD000
      driver-class-name: com.ibm.db2.jcc.DB2Driver
      username: ${adqemp-db2-crim-usr-00001}
      password: ${adqemp-db2-crim-pwd-00001}
      connectionPoolInitialSize: 2

#Banco de Dados: SQLSERVER
spring:
  sqlserver:
    datasource:
      url: jdbc:sqlserver://${SQLSERVER_HOST}:${SQLSERVER_PORT};database=${SQLSERVER_DB};encrypt=true;trustServerCertificate=true
      username: ${SQLSERVER_USER}
      password: ${SQLSERVER_PASS}
      driver-class-name: com.microsoft.sqlserver.jdbc.SQLServerDriver
      connectionPoolInitialSize: 2
```