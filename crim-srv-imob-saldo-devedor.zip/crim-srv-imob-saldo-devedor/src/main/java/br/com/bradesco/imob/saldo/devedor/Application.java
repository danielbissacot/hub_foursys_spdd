package br.com.bradesco.imob.saldo.devedor;

import br.com.bradesco.enge.logcloud.spring.EnableLogCloud;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;

import java.util.Arrays;

import static org.apache.commons.lang3.StringUtils.defaultIfBlank;

/**
 * Classe principal da aplicação Spring Boot para o sistema de documentos FGTS.
 *
 * @author Sistema Imobiliário Bradesco
 */
@SpringBootApplication
@EnableLogCloud
@ComponentScan(basePackages = {"br.com.bradesco.imob"})
public class Application implements CommandLineRunner {

    private static final Logger LOGGER_TECNICO = LoggerFactory.getLogger(Application.class);

    private final Environment environment;

    /**
     * Construtor da classe Application.
     *
     * @param environment O ambiente Spring, usado para acessar perfis ativos.
     */
    public Application(Environment environment) {
        this.environment = environment;
    }

    /**
     * Método principal que inicia a aplicação Spring Boot.
     *
     * @param args Argumentos de linha de comando.
     */
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    /**
     * Executa a lógica de inicialização da aplicação após o Spring Boot ter iniciado.
     * Este método é usado para logar os perfis ativos da aplicação.
     *
     * @param args Argumentos de linha de comando.
     */
    @Override
    public void run(String... args) throws Exception {
        String activeProfile = Arrays.toString(environment.getActiveProfiles());
        String profiles = defaultIfBlank(activeProfile.replace("[]", ""), "[DEFAULT]");
        LOGGER_TECNICO.info("ACTIVE PROFILES: {}", profiles);
    }
}