package br.com.bradesco.imob.saldo.devedor.adapter.in.exception;

import br.com.bradesco.imob.saldo.devedor.application.exception.ServiceException;
import br.com.bradesco.imob.saldo.devedor.application.exception.ServicoIndisponivelException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;

/**
 * Handler global de exceções para a camada de API.
 * <p>
 * Responsável por traduzir exceções de domínio e de sistema em respostas HTTP
 * padronizadas, garantindo que nenhum detalhe de implementação vaze para o cliente.
 */
@ControllerAdvice
public class GlobalApiExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalApiExceptionHandler.class);

    /**
     * Trata {@link ServiceException} lançada quando um recurso de negócio não é encontrado
     * ou quando uma regra de validação de domínio é violada.
     * Retorna HTTP 404 (Not Found).
     *
     * @param ex A exceção de domínio capturada.
     * @return Uma resposta HTTP padronizada para o erro.
     */
    @ExceptionHandler(ServiceException.class)
    public ResponseEntity<ApiErrorResponse> handleServiceException(ServiceException ex) {
        var errorResponse = new ApiErrorResponse(
                LocalDateTime.now(),
                HttpStatus.NOT_FOUND.value(),
                "Not Found",
                ex.getMessage()
        );
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

    /**
     * Trata exceções de negócio quando um recurso específico não é encontrado.
     * Retorna HTTP 404 (Not Found).
     *
     * @param ex A exceção de domínio capturada.
     * @return Uma resposta HTTP padronizada para o erro.
     */
    @ExceptionHandler(ServicoIndisponivelException.class)
    public ResponseEntity<ApiErrorResponse> handleContratoNaoEncontrado(ServicoIndisponivelException ex){
        var errorResponse = new ApiErrorResponse(
                LocalDateTime.now(),
                HttpStatus.NOT_FOUND.value(),
                "Not Found",
                ex.getMessage()
        );
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

    /**
     * Handler "catch-all" para qualquer outra exceção não tratada.
     * Atua como uma barreira de segurança para evitar o vazamento de stack traces.
     * Retorna HTTP 500 (Internal Server Error).
     *
     * @param ex A exceção inesperada capturada.
     * @param request O contexto da requisição web atual.
     * @return Uma resposta HTTP genérica de erro interno.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponse> handleGenericException(Exception ex, WebRequest request){
        LOGGER.error("Ocorreu uma exceção não tratada: {}", ex.getMessage(), ex);

        var errorResponse = new ApiErrorResponse(
                LocalDateTime.now(),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Internal Server Error",
                "Ocorreu um erro interno inesperado. Por favor, tente novamente mais tarde."
        );

        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * DTO padrão para respostas de erro da API.
     *
     * @param timestamp O momento em que o erro ocorreu.
     * @param status O código de status HTTP.
     * @param error O nome do erro HTTP (ex: "Not Found").
     * @param message A mensagem descritiva do erro.
     */
    record ApiErrorResponse(
            LocalDateTime timestamp,
            int status,
            String error,
            String message
    ) {}
}