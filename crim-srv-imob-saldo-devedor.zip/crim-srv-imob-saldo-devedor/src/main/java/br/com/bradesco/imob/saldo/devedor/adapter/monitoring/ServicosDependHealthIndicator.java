package br.com.bradesco.imob.saldo.devedor.adapter.monitoring;

import br.com.bradesco.imob.saldo.devedor.adapter.monitoring.entity.HealthCheckServDepend;
import br.com.bradesco.imob.saldo.devedor.adapter.monitoring.entity.HealthCheckServDependGeral;
import br.com.bradesco.imob.lib.common.config.HealthCheckEndpointConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Implementação personalizada de {@link HealthIndicator} para monitorar a saúde
 * de serviços dependentes externos.
 * <p>
 * Esta classe é responsável por realizar requisições de Health Check (geralmente para o endpoint "/health")
 * em uma lista de URLs de serviços dependentes configuradas. Ela agrega os resultados
 * e reporta o status geral de saúde desses serviços para o Spring Boot Actuator.
 * </p>
 * <p>
 * **OPCIONAL:**
 * <ul>
 *     <li>Pode ser removido caso não seja considerado necessário monitorar explicitamente
 *         serviços dependentes através deste mecanismo.</li>
 *     <li>Se removido, lembre-se de excluir também o mapeamento no arquivo
 *         {@code application.yml} em {@code management.endpoint.health.group.readiness.include}.</li>
 * </ul>
 * </p>
 * <p>
 * **NOTA:**
 * Por padrão, o HealthCheck do Spring Actuator já está ativo e monitora componentes internos.
 * Esta classe estende essa funcionalidade para dependências externas.
 * </p>
 * <p>
 * A ativação deste indicador é controlada pela propriedade
 * {@code management.health.servicosDependentes.enabled=true} no {@code application.yml}.
 * </p>
 */
@ConditionalOnProperty(prefix = "management.health.servicosDependentes", name = "enabled", havingValue = "true")
@Component
public class ServicosDependHealthIndicator implements HealthIndicator {

    /**
     * Logger técnico para registrar erros e informações detalhadas sobre as requisições
     * de Health Check.
     */
    private static final Logger LOGGER_TECNICO = LoggerFactory.getLogger(
            ServicosDependHealthIndicator.class);

    /**
     * Configuração contendo a lista de URLs dos endpoints de Health Check dos serviços dependentes.
     */
    private final HealthCheckEndpointConfig healthCheckEndpointConfig;

    /**
     * Cliente HTTP para realizar as requisições aos endpoints de Health Check dos serviços.
     */
    private final RestTemplate restTemplate;

    /**
     * Construtor que injeta as dependências necessárias para o indicador de saúde.
     *
     * @param healthCheckEndpointConfig Configuração dos endpoints de Health Check dos serviços dependentes.
     * @param restTemplate              Cliente HTTP para realizar as requisições.
     */
    @Autowired
    public ServicosDependHealthIndicator(HealthCheckEndpointConfig healthCheckEndpointConfig,
                                         RestTemplate restTemplate) {
        this.healthCheckEndpointConfig = healthCheckEndpointConfig;
        this.restTemplate = restTemplate;
    }

    /**
     * Verifica a saúde de todos os serviços dependentes configurados.
     * <p>
     * Este método itera sobre a lista de URLs de endpoints de Health Check,
     * realizando requisições assíncronas para cada um. Ele coleta os resultados
     * e determina se todos os serviços estão com status "UP".
     * </p>
     *
     * @return Um {@link HealthCheckServDependGeral} contendo a lista detalhada
     *         dos resultados de Health Check e um booleano indicando se todos os
     *         serviços estão "UP".
     */
    private HealthCheckServDependGeral verificaSaudeServicosDependentes() {
        List<HealthCheckServDepend> listaHealthCheckServDepend = null;
        boolean flagTodosServicosUp = false;
        List<String> urlsDependenteList = this.healthCheckEndpointConfig.getEndpoints();

        if (!CollectionUtils.isEmpty(urlsDependenteList)) {
            // Realiza as requisições aos endpoints de forma assíncrona para não bloquear o thread principal
            listaHealthCheckServDepend =
                    urlsDependenteList.stream()
                            .map(url -> CompletableFuture.supplyAsync(() ->
                                    requisitaEndpoint(url)))
                            .map(CompletableFuture::join).toList(); // Espera todas as requisições completarem

            // Verifica se todos os serviços retornaram status UP
            flagTodosServicosUp = listaHealthCheckServDepend.stream().allMatch(healthResponseEntity ->
                    healthResponseEntity.health().getStatus().equals(Status.UP));
        }

        return new HealthCheckServDependGeral(listaHealthCheckServDepend, flagTodosServicosUp);
    }

    /**
     * Realiza uma requisição HTTP GET para o endpoint de Health Check de um serviço.
     * <p>
     * Tenta obter o status de saúde de um serviço dependente. Se a requisição for
     * bem-sucedida (código 2xx), retorna um status {@link Status#UP}. Em caso de
     * erro na requisição (ex: conexão recusada, timeout) ou outros códigos de status,
     * retorna um status {@link Status#DOWN}.
     * </p>
     *
     * @param urlEndpointHealth A URL completa do endpoint de Health Check do serviço.
     * @return Um {@link HealthCheckServDepend} contendo a URL e o status de saúde
     *         (UP ou DOWN) do serviço.
     */
    private HealthCheckServDepend requisitaEndpoint(String urlEndpointHealth) {
        try {
            ResponseEntity<Object> response = restTemplate.getForEntity(urlEndpointHealth, Object.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                return new HealthCheckServDepend(urlEndpointHealth, new Health.Builder().up().build());
            }
            // Se o status não for 2xx, mas também não lançou exceção, consideramos DOWN
            // Pode ser refinado para tratar outros códigos de status específicos, se necessário.
        } catch (RestClientException ex) {
            LOGGER_TECNICO.error("Error while trying to request endpoint /health from URL {}",
                    urlEndpointHealth, ex);
        }
        // Em caso de exceção ou status não 2xx, o serviço é considerado DOWN
        return new HealthCheckServDepend(urlEndpointHealth, new Health.Builder().down().build());
    }

    /**
     * Retorna o status de saúde geral dos serviços dependentes.
     * <p>
     * Este é o método principal da interface {@link HealthIndicator}. Ele invoca
     * {@link #verificaSaudeServicosDependentes()} para obter o status de todas as
     * dependências e constrói um objeto {@link Health} apropriado.
     * </p>
     * <ul>
     *     <li>Se todos os serviços dependentes estiverem "UP", retorna {@link Health#up()}.</li>
     *     <li>Caso contrário, retorna {@link Health#down()} com detalhes sobre o status
     *         de cada serviço dependente.</li>
     * </ul>
     *
     * @return Um objeto {@link Health} indicando o status geral dos serviços dependentes.
     */
    @Override
    public Health health(){
        HealthCheckServDependGeral servicosDependentes = verificaSaudeServicosDependentes();
        if (!servicosDependentes.todosServicosUP()) {
            return Health.down().withDetails(Map.of("statusServicosDependentes", servicosDependentes))
                    .build();
        }
        return Health.up().build();
    }

}