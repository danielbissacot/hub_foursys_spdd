package br.com.bradesco.imob.saldo.devedor.adapter.monitoring.entity;

import org.springframework.boot.actuate.health.Health;

/**
 * Representa o resultado de um Health Check para um serviço dependente específico.
 * <p>
 * Este record encapsula a URL do serviço dependente que foi verificado
 * e o {@link Health} retornado por essa verificação. É utilizado para
 * agregar informações sobre a saúde de cada dependência externa da aplicação.
 * </p>
 *
 * @param url    A URL do serviço dependente que foi alvo do Health Check.
 * @param health O objeto {@link Health} que contém o status e detalhes
 *               da saúde do serviço dependente.
 */
public record HealthCheckServDepend(String url, Health health){
}