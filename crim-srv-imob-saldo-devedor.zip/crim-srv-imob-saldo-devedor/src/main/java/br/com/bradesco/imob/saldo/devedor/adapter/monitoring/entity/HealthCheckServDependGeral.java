package br.com.bradesco.imob.saldo.devedor.adapter.monitoring.entity;

import java.util.List;

/**
 * Agrega os resultados de múltiplos Health Checks de serviços dependentes.
 * <p>
 * Este record serve como um contêiner para o status de saúde consolidado de todas
 * as dependências externas da aplicação, fornecendo tanto uma lista detalhada
 * quanto um indicador booleano de status geral.
 * </p>
 *
 * @param healthCheckServDependList Uma lista contendo o resultado detalhado do Health Check
 *                                  para cada serviço dependente.
 * @param todosServicosUP           Um indicador booleano que é {@code true} se todos os serviços
 *                                  na lista estão com status "UP", e {@code false} caso contrário.
 */
public record HealthCheckServDependGeral(List<HealthCheckServDepend> healthCheckServDependList,
                                         boolean todosServicosUP) {
}
