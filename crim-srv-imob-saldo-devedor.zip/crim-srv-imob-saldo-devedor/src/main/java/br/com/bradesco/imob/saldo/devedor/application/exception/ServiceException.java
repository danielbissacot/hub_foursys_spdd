package br.com.bradesco.imob.saldo.devedor.application.exception;

import java.io.Serial;

/**
 * Exceção de runtime para falhas genéricas na camada de serviço da aplicação.
 * <p>
 * Usada para encapsular erros de negócio ou de integração que não se enquadram
 * em tipos de exceção mais específicos, como {@link ServicoIndisponivelException}.
 * Permite propagar mensagens de erro claras para a camada de apresentação sem
 * expor detalhes técnicos de implementação.
 */
public class ServiceException extends RuntimeException{
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Descrição do erro de serviço ocorrido.
     *
     * @param message descrição do erro de serviço ocorrido.
     */
    public ServiceException(String message) {
        super(message);
    }

    /**
     * Descrição do erro de serviço ocorrido.
     *
     * @param message descrição do erro de serviço ocorrido.
     * @param cause   exceção original que motivou esta falha.
     */
    public ServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Descrição do erro de serviço ocorrido.
     *
     * @param cause exceção original que motivou esta falha.
     */
    public ServiceException(Throwable cause) {
        super(cause);
    }

}
