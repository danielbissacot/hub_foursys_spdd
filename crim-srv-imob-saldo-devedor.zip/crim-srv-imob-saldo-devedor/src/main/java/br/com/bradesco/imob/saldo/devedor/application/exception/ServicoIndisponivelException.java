package br.com.bradesco.imob.saldo.devedor.application.exception;

/**
 * Exceção lançada quando um serviço está temporariamente indisponível ou inacessível.
 * <p>
 * Esta exceção é utilizada para indicar falhas relacionadas à indisponibilidade de 
 * serviços externos, problemas de conectividade ou quando recursos necessários 
 * não estão acessíveis no momento da requisição.
 * </p>
 * <p>
 * Herda de {@link RuntimeException}, sendo uma exceção não verificada.
 * </p>
 */
public class ServicoIndisponivelException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private final String errorCode;
    private final String errorMsg;

    /**
     * Construtor que cria uma exceção com código de erro numérico, mensagem e causa.
     *
     * @param errorCode código numérico do erro
     * @param errorMsg mensagem descritiva do erro
     * @param cause causa raiz da exceção
     */
    public ServicoIndisponivelException(Integer errorCode, String errorMsg, Throwable cause) {
        super(errorMsg, cause);
        this.errorCode = Integer.toString(errorCode);
        this.errorMsg = errorMsg;
    }

    /**
     * Construtor que cria uma exceção com mensagem e causa, sem código de erro.
     *
     * @param errorMsg mensagem descritiva do erro
     * @param cause causa raiz da exceção
     */
    public ServicoIndisponivelException(String errorMsg, Throwable cause) {
        super(errorMsg, cause);
        this.errorCode = null;
        this.errorMsg = errorMsg;
    }

    /**
     * Construtor que cria uma exceção com código de erro textual, mensagem e causa.
     *
     * @param errorCode código textual do erro
     * @param errorMsg mensagem descritiva do erro
     * @param cause causa raiz da exceção
     */
    public ServicoIndisponivelException(String errorCode, String errorMsg, Throwable cause) {
        super(errorMsg, cause);
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    /**
     * Construtor que cria uma exceção com código de erro numérico e mensagem.
     *
     * @param errorCode código numérico do erro
     * @param errorMsg mensagem descritiva do erro
     */
    public ServicoIndisponivelException(Integer errorCode, String errorMsg) {
        super(errorMsg);
        this.errorCode = Integer.toString(errorCode);
        this.errorMsg = errorMsg;
    }

    /**
     * Construtor que cria uma exceção com código de erro textual e mensagem.
     *
     * @param errorCode código textual do erro
     * @param errorMsg mensagem descritiva do erro
     */
    public ServicoIndisponivelException(String errorCode, String errorMsg) {
        super();
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    /**
     * Obtém o código do erro associado à exceção.
     *
     * @return código do erro, ou {@code null} se não foi definido
     */
    public String getErrCode(){
        return errorCode;
    }

    /**
     * Obtém a mensagem de erro associada à exceção.
     *
     * @return mensagem descritiva do erro
     */
    public String getErrMsg(){
        return errorMsg;
    }
}