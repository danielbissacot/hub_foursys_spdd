package br.com.bradesco.imob.arch;

import br.com.bradesco.imob.codereview.rules.HexagonalArchitectureRules;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;

/**
 * <p>
 * Ponto de entrada para a validação das regras da Arquitetura Hexagonal neste projeto.
 * </p>
 *
 * <p>
 * Esta classe de teste tem como único objetivo acionar as verificações de arquitetura
 * definidas na classe base {@link HexagonalArchitectureRules}. Ao herdar desta classe,
 * todos os testes de arquitetura (ArchUnit) são automaticamente executados contra os
 * pacotes especificados na anotação {@code @AnalyzeClasses}.
 * </p>
 *
 * <p>
 * Nenhuma implementação adicional é necessária aqui. Esta abordagem centraliza as
 * regras de arquitetura num local comum, garantindo consistência e reuso entre
 * diferentes microserviços.
 * </p>
 *
 * @see HexagonalArchitectureRules
 */
@AnalyzeClasses(packages = "br.com.bradesco.imob.saldo.devedor",
        importOptions = {ImportOption.DoNotIncludeTests.class})
class HexagonalArchitectureRulesTest extends HexagonalArchitectureRules {
    // Nenhuma implementação é necessária, pois toda a lógica de validação
    // é herdada da classe HexagonalArchitectureRules.
}